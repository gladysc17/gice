

<?php $__env->startSection('content'); ?>

<h1>Lineas de Investigación</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('linea', [])->html();
} elseif ($_instance->childHasBeenRendered('8cyzPIf')) {
    $componentId = $_instance->getRenderedChildComponentId('8cyzPIf');
    $componentTag = $_instance->getRenderedChildComponentTagName('8cyzPIf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8cyzPIf');
} else {
    $response = \Livewire\Livewire::mount('linea', []);
    $html = $response->html();
    $_instance->logRenderedChild('8cyzPIf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('linea creada', function() {
        Swal.fire(
            'Linea creada correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearLinea').modal('hide');
    })
    Livewire.on('linea borrada', function() {
        Swal.fire(
            'Linea borrada correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('linea editada', function() {
        Swal.fire(
            'Linea editada correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarLinea').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/linea.blade.php ENDPATH**/ ?>
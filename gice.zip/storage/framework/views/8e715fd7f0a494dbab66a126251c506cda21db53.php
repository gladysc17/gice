<div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Tabla de Lineas de Investigación</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="d-flex flex-row-reverse my-3">
                <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#crearLinea">Crear Linea</button>

            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Nombre</th>
                        <th>Objetivo</th>
                        <th>Logros</th>
                        <th>Efectos</th>
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($lineas->count()): ?>
                    <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($linea->nombre); ?></td>
                        <td><?php echo e($linea->objetivo); ?></td>
                        <td><?php echo e($linea->logros->count()); ?></td>
                        <td><?php echo e($linea->efectos->count()); ?></td>
                        <td>
                            <button class="btn btn-warning" type="button" wire:click="edit(<?php echo e($linea->id); ?>)" data-toggle="modal" data-target="#editarLinea">Editar</button>
                            <button class="btn btn-danger" type="button" onclick="confirm('Esta seguro de borrar la Linea?') || event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($linea->id); ?>)">Borrar</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p>No hay Lineas</p>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer clearfix">
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="crearLinea" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Crear Linea</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="newLinea" wire:submit.prevent="save">
                        <div class="form-group">
                            <label for="nomnbreLinea">Nombre:</label>
                            <textarea class="form-control" id="nombreLinea" rows="3" placeholder="Ingrese la Linea" required wire:model.defer="nombre"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="objetivoLinea">Objetivo:</label>
                            <textarea class="form-control" id="objetivoLinea" rows="3" placeholder="Ingrese el objetivo" required wire:model.defer="objetivo"></textarea>
                        </div>
                        <table class="table" id="createLogros">
                            <thead>
                                <tr>
                                    <th>Logros</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $logros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><textarea class="form-control" rows="3" wire:model.defer="logros.<?php echo e($index); ?>.logro" placeholder="Ingrese el logro" required></textarea></td>
                                    <?php if(count($logros)>1): ?>
                                    <td><button class="btn btn-danger" type="button" wire:click.prevent="removeLogro(<?php echo e($index); ?>)">Borrar</button></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-sm btn-secondary" wire:click.prevent="addLogro">+ agregar otro logro</button>
                            </div>
                        </div>

                        <table class="table" id="createEfectos">
                            <thead>
                                <tr>
                                    <th>Efectos</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $efectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $efe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><textarea class="form-control" rows="3" wire:model.defer="efectos.<?php echo e($index); ?>.efecto" placeholder="Ingrese el efecto" required></textarea></td>
                                    <?php if(count($efectos)>1): ?>
                                    <td><button class="btn btn-danger" type="button" wire:click.prevent="removeEfecto(<?php echo e($index); ?>)">Borrar</button></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-sm btn-secondary" wire:click.prevent="addEfecto">+ agregar otro efecto</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary" form="newLinea">Guardar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="editarLinea" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Linea</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editLinea" wire:submit.prevent="update">
                        <div class="form-group">
                            <label for="nombreLinea">Linea:</label>
                            <textarea class="form-control" id="nombreLinea" rows="3" aria-describedby="emailHelp" placeholder="Ingrese la Linea" required wire:model.defer="nombre"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="objetivoLinea">Objetivo:</label>
                            <textarea class="form-control" id="objetivoLinea" rows="3" aria-describedby="emailHelp" placeholder="Ingrese el objetivo" required wire:model.defer="objetivo"></textarea>
                        </div>
                        <table class="table" id="editLogros">
                            <thead>
                                <tr>
                                    <th>Logro</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $logros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><textarea class="form-control" rows="3" wire:model="logros.<?php echo e($index); ?>.logro" placeholder="Ingrese el logro" required></textarea></td>
                                    <?php if(count($logros)>1): ?>
                                    <td><button class="btn btn-danger" type="button" wire:click.prevent="removeEditLogro(<?php echo e($index); ?>)">Borrar</button></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-sm btn-secondary" wire:click.prevent="addLogro">+ agregar otro logro</button>
                            </div>
                        </div>

                        <table class="table" id="editEfectos">
                            <thead>
                                <tr>
                                    <th>Efectos</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $efectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $efe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><textarea class="form-control" rows="3" wire:model="efectos.<?php echo e($index); ?>.efecto" placeholder="Ingrese el efecto" required></textarea></td>
                                    <?php if(count($efectos)>1): ?>
                                    <td><button class="btn btn-danger" type="button" wire:click.prevent="removeEditEfecto(<?php echo e($index); ?>)">Borrar</button></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-sm btn-secondary" wire:click.prevent="addEfecto">+ agregar otro efecto</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary" form="editLinea">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/livewire/linea.blade.php ENDPATH**/ ?>
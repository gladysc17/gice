

<?php $__env->startSection('content'); ?>

<h1>Mision y Vision</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('presentacion', [])->html();
} elseif ($_instance->childHasBeenRendered('OXAnJQG')) {
    $componentId = $_instance->getRenderedChildComponentId('OXAnJQG');
    $componentTag = $_instance->getRenderedChildComponentTagName('OXAnJQG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OXAnJQG');
} else {
    $response = \Livewire\Livewire::mount('presentacion', []);
    $html = $response->html();
    $_instance->logRenderedChild('OXAnJQG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('presentacion creada', function() {
        Swal.fire(
            'Presentacion Creada Correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearPresentacion').modal('hide');
    })
    Livewire.on('presentacion borrada', function() {
        Swal.fire(
            'Presentacion borrada Correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('presentacion editada', function() {
        Swal.fire(
            'presentacion editada Correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarPresentacion').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/presentacion.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<h1>Proyectos</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('proyecto', [])->html();
} elseif ($_instance->childHasBeenRendered('gBy90i9')) {
    $componentId = $_instance->getRenderedChildComponentId('gBy90i9');
    $componentTag = $_instance->getRenderedChildComponentTagName('gBy90i9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gBy90i9');
} else {
    $response = \Livewire\Livewire::mount('proyecto', []);
    $html = $response->html();
    $_instance->logRenderedChild('gBy90i9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('Proyecto registrado', function() {
        Swal.fire(
            'Proyecto creado correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearProyecto').modal('hide');
    })
    Livewire.on('Proyecto borrado', function() {
        Swal.fire(
            'Proyecto borrado correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('Proyecto editado', function() {
        Swal.fire(
            'Proyecto editado correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarProyecto').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/proyecto.blade.php ENDPATH**/ ?>
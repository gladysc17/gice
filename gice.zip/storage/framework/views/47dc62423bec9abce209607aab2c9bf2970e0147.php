

<?php $__env->startSection('content'); ?>

<h1>Semilleros</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('semillero', [])->html();
} elseif ($_instance->childHasBeenRendered('hjej90d')) {
    $componentId = $_instance->getRenderedChildComponentId('hjej90d');
    $componentTag = $_instance->getRenderedChildComponentTagName('hjej90d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hjej90d');
} else {
    $response = \Livewire\Livewire::mount('semillero', []);
    $html = $response->html();
    $_instance->logRenderedChild('hjej90d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('Semillero registrado', function() {
        Swal.fire(
            'Semillero creado correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearSemillero').modal('hide');
    })
    Livewire.on('Semillero borrado', function() {
        Swal.fire(
            'Semillero borrado correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('Semillero editado', function() {
        Swal.fire(
            'Semillero editado correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarSemillero').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto ufps\gice\resources\views/semillero.blade.php ENDPATH**/ ?>
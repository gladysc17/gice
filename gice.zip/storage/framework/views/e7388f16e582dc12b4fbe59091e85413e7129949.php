

<?php $__env->startSection('content'); ?>

<h1>Investigadores</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('investigador', [])->html();
} elseif ($_instance->childHasBeenRendered('wpG2J1W')) {
    $componentId = $_instance->getRenderedChildComponentId('wpG2J1W');
    $componentTag = $_instance->getRenderedChildComponentTagName('wpG2J1W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wpG2J1W');
} else {
    $response = \Livewire\Livewire::mount('investigador', []);
    $html = $response->html();
    $_instance->logRenderedChild('wpG2J1W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('Investigador(a) registrado (a)', function() {
        Swal.fire(
            'Investigador creado correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearInvestigador').modal('hide');
    })
    Livewire.on('Investigador(a) borrado(a)', function() {
        Swal.fire(
            'Investigador(a) borrado(a) correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('Investigador(a) editado(a)', function() {
        Swal.fire(
            'investigador editado(a) correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarInvestigador').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/investigador.blade.php ENDPATH**/ ?>
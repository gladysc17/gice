

<?php $__env->startSection('content'); ?>

<h1>Evento</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('evento', [])->html();
} elseif ($_instance->childHasBeenRendered('dULAMCP')) {
    $componentId = $_instance->getRenderedChildComponentId('dULAMCP');
    $componentTag = $_instance->getRenderedChildComponentTagName('dULAMCP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dULAMCP');
} else {
    $response = \Livewire\Livewire::mount('evento', []);
    $html = $response->html();
    $_instance->logRenderedChild('dULAMCP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('evento registrado', function() {
        Swal.fire(
            'Evento creado correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearEvento').modal('hide');
    })
    Livewire.on('evento borrado', function() {
        Swal.fire(
            'Evento borrado correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('evento editado', function() {
        Swal.fire(
            'Evento editado correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarEvento').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto ufps\gice\resources\views/evento.blade.php ENDPATH**/ ?>
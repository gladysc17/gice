

<?php $__env->startSection('content'); ?>

<h1>Listado de Servicios</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('servicio', [])->html();
} elseif ($_instance->childHasBeenRendered('HdzHb7l')) {
    $componentId = $_instance->getRenderedChildComponentId('HdzHb7l');
    $componentTag = $_instance->getRenderedChildComponentTagName('HdzHb7l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HdzHb7l');
} else {
    $response = \Livewire\Livewire::mount('servicio', []);
    $html = $response->html();
    $_instance->logRenderedChild('HdzHb7l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('servicio creado', function() {
        Swal.fire(
            'servicio Creado Correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearServicio').modal('hide');
    })
    Livewire.on('servicio borrado', function() {
        Swal.fire(
            'servicio borrado Correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('servicio editado', function() {
        Swal.fire(
            'Servicio editado Correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarServicio').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/servicio.blade.php ENDPATH**/ ?>
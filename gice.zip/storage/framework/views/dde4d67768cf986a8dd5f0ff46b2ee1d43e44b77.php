<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GINCUS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/dc4f193fbc.js" crossorigin="anonymous"></script>
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.11.0/css/mdb.min.css" rel="stylesheet">
    <meta name="description" content="GINCUS">
    <meta name="keywords" content="GINCUS">
    
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="grey lighten-3">
    <header class="py-4 animated fadeInUp d-none d-lg-block" style="background-image: url('<?php echo e(asset('img/header-superior-principal.jpg')); ?>'); background-attachment: fixed;">
        <div class="container">
            <div class="row align-items-center">
            <div class="col-2">
                    <a  href="<?php echo e(url('/')); ?>"> <img src="/img/gincus.png" alt="" class="img-fluid" title="LOGO GICE"> </a>
                </div>
                <div class="col-6">
                    <h1 class="h1">GINCUS</h1>
                    <h4 class="h4"> Grupo de Investigación para el cuidado de la Salud</h4>
                </div>

                <div class="col-lg-4 ml-auto ">
                    <img src="/img/logo-ufps.png" class="img-fluid" title="UFPS">
                </div>
            </div>
        </div>

    </header>


    <nav class="navbar sticky-top navbar-expand-lg text-center navbar-dark danger-color-dark animated fadeInUp slow">
        <a class="navbar-brand" href="#">
            <img src="/img/gincus.png" height="50" alt="mdb logo">
            <strong>GINCUS</strong>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    PRESENTACIÓN</a>

                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(url('/#presentacion')); ?>">Misión & Visión</a>
                        <a class="dropdown-item" href="<?php echo e(url('/#objetivos')); ?>">Objetivos</a>
                        <a class="dropdown-item" href="<?php echo e(url('/#valores')); ?>">Valores</a>
                        <!--<a class="dropdown-item" href="#">Imagen corporativa</a>-->
                        <a class="dropdown-item" href="<?php echo e(url('linea')); ?>">Lineas de Investigación</a>
                        <a class="dropdown-item" href="<?php echo e(url('investigador')); ?>">Investigadores</a>
                        <a class="dropdown-item" href="<?php echo e(url('/#servicios')); ?>">Servicios</a>
                        <a class="dropdown-item" href="#">Contacto</a>
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('proyecto')); ?>">PROYECTOS </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('red')); ?>">REDES</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('evento')); ?>">EVENTOS</a>
                </li>
                
                 <li class="nav-item">
                    <a class="nav-link" href="#">PUBLICACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">RECOPILACIÓN PANELES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('semillero')); ?>">SEMILLEROS</a>
                </li>
            </ul>
        </div>
    </nav>


   


    <div class="container" style='margin: 20px; padding: 50px;'>
  
            <div class="row">
                <div class="col">
                
                </div>
                
                <div class="col-10">
               

                <div class="col-md-12 col-sm-12 col-xs-12" style="border-bottom: 3px solid #aa1916;">
                    <div class="row">
                        <div class="col-md-12">
                                <h1 style="font-size: 30px;">
                                <b>Semilleros de Investigación</b></h1>
                        </div>
                    </div>
                </div>

                    <div class="container-fluid">
                        <div class="row">
                        <table class="table table-responsive">
                            <thead>
                                <tr style="text-align: center">
                                    <th scope="col">Semillero </th>
                                    <th scope="col">Caracteristicas</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(count($semillero)): ?>
                            <?php $__currentLoopData = $semillero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr >
                                    <th style="text-align: center">
                                            <h4> <?php echo e($sem->sigla); ?> </h4>
                                            <h5> <?php echo e($sem->nombre); ?> </h5>
                                            <img src="<?php echo e(asset('img/'.$sem->logo.'.png')); ?>" alt="" class="img-fluid" title="LOGO">
                                    </th>

                                    <th style="text-align: justify"> 
                                        <h5>Fecha de creación: </h5> <p> <?php echo e($sem->fechacreacion); ?> </p>
                                        <h5>Objeto: </h5> <p><?php echo e($sem->objeto); ?> </p>
                                        <h5>Director: </h5> <p><?php echo e($sem->director); ?> </p>
                                        <h5>Correo: </h5> <p><?php echo e($sem->correo); ?> </p>
                                        <h5>Actividades destacadas: </h5><p><?php echo e($sem->caracteristicas); ?> </p>
                                    </th>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <p>No hay semilleros registrados</p>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                    </div>


                </div>
                <div class="col">
               
                </div>
            </div>
    </div>

    <!-- Footer -->
    <footer class="page-footer font-small bg-dark text-white pt-4">



        <!-- Footer Links -->
        <div class="container-fluid text-center text-md-left">


            <!-- Grid row -->
            <div class="row">

                <!-- Grid column -->
                <div class="col-md-6 mt-md-0 mt-3">

                    <!-- Content -->
                    <h5 class="text-uppercase"><?php echo e(config('app.name', 'Laravel')); ?></h5>
                    <?php if($contacto): ?>
                    <p>Nombre: <?php echo e($contacto->nombre); ?>

                        <br>E-mail: <a href="mailto:<?php echo e($contacto->correo); ?>" target="_blank"><?php echo e($contacto->correo); ?></a><br>
                        Telefono: <?php echo e($contacto->telefono); ?> <br>
                        Direccion: <?php echo e($contacto->direccion); ?> <br>
                        Cúcuta - Norte de Santander - Colombia
                    </p>
                    <?php endif; ?>

                </div>
                <!-- Grid column -->

                <hr class="clearfix w-100 d-md-none pb-3">

                <!-- Grid column -->
                

        </div>
        <!-- Grid row -->

        </div>
        <!-- Footer Links -->
        <div class="container text-center">
            <!-- Section: Social media -->
            <p>Siguenos:</p>
            <section>
                <!-- Facebook -->
                <a class="btn btn-outline-light btn-floating m-1" href="https://www.facebook.com/camaracucuta" role="button" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <!-- Twitter -->
                <a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/cccucuta" role="button" target="_blank"><i class="fab fa-twitter"></i></a>
                <!-- Instagram -->
                <a class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/camaracucuta/" role="button" target="_blank"><i class="fab fa-instagram"></i></a>
            </section>
            <!-- Section: Social media -->
        </div>

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2021 Copyright:
            <a href="#"><?php echo e(config('app.name', 'Laravel')); ?></a>
        </div>
        <!-- Copyright -->

    </footer>
    <!-- Footer -->


    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\Users\gladys\Documents\Proyecto ufps\gice\resources\views/cliente/semillero.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<h1>Listado de Valores</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('valor', [])->html();
} elseif ($_instance->childHasBeenRendered('zllPNRg')) {
    $componentId = $_instance->getRenderedChildComponentId('zllPNRg');
    $componentTag = $_instance->getRenderedChildComponentTagName('zllPNRg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zllPNRg');
} else {
    $response = \Livewire\Livewire::mount('valor', []);
    $html = $response->html();
    $_instance->logRenderedChild('zllPNRg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('valor creado', function() {
        Swal.fire(
            'valor Creado Correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearValor').modal('hide');
    })
    Livewire.on('valor borrado', function() {
        Swal.fire(
            'Valor borrado Correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('valor editado', function() {
        Swal.fire(
            'valor editado Correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarValor').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/valor.blade.php ENDPATH**/ ?>
<div class="row p-lg-5 pb-5 align-items-center" style="background-color: #b43432;" id="servicios">
    <div class="col-12 my-4 wow fadeIn">
        <h1 class="text-center font-weight-bold white-text">Servicios</h1>
    </div>
    <?php if($servicios->count()): ?>
    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-center" ><?php echo e($serv->nombre); ?></h5>
                <p class="card-text"><?php echo e(Str::limit($serv->descripcion, 230)); ?></p>
                <button class="btn btn-danger" type="button" wire:click="selected(<?php echo e($serv->id); ?>)" data-toggle="modal" data-target="#serviceModal">Ver Mas</button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- Modal -->
    <div class="modal fade" id="serviceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if($servicio): ?>
                    <h3 class="modal-title" id="exampleModalLabel"><?php echo e($servicio->nombre); ?></h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?php endif; ?>
                </div>
                <div class="modal-body">
                    <?php if($servicio): ?>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <h4>Descripción:</h4>
                                <p><?php echo e($servicio->descripcion); ?></p>
                            </div>
                            <div class="col-12">
                                <h4>Componentes:</h4>
                                <ul class="list-group">
                                    <?php $__currentLoopData = $servicio->componentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <il class="list-group-item"><?php echo e($comp->componente); ?></il>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\gladys\Documents\Proyecto ufps\gice\resources\views/livewire/servicio-front.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<h1>Contacto</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contacto', [])->html();
} elseif ($_instance->childHasBeenRendered('6D4ACZn')) {
    $componentId = $_instance->getRenderedChildComponentId('6D4ACZn');
    $componentTag = $_instance->getRenderedChildComponentTagName('6D4ACZn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6D4ACZn');
} else {
    $response = \Livewire\Livewire::mount('contacto', []);
    $html = $response->html();
    $_instance->logRenderedChild('6D4ACZn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('contacto registrado', function() {
        Swal.fire(
            'Contacto creado correctamente',
            'Se ha creado con exito',
            'success'
        )
        $('#crearContacto').modal('hide');
    })
    Livewire.on('contacto borrado', function() {
        Swal.fire(
            'Contacto borrado correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('contacto editado', function() {
        Swal.fire(
            'Contacto editado correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarContacto').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/contacto.blade.php ENDPATH**/ ?>
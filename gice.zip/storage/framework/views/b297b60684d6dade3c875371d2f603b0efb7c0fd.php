

<?php $__env->startSection('content'); ?>

<h1>Objetivos del grupo</h1>
<div class="row justify-content-md-center">
    <div class="col-md-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('objetivo', [])->html();
} elseif ($_instance->childHasBeenRendered('tY8V8fa')) {
    $componentId = $_instance->getRenderedChildComponentId('tY8V8fa');
    $componentTag = $_instance->getRenderedChildComponentTagName('tY8V8fa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tY8V8fa');
} else {
    $response = \Livewire\Livewire::mount('objetivo', []);
    $html = $response->html();
    $_instance->logRenderedChild('tY8V8fa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    Livewire.on('Objetivo creado', function() {
        Swal.fire(
            'Objetivo creado correctamente',
            'Se ha creado con éxito',
            'success'
        )
        $('#crearObjetivo').modal('hide');
    })
    Livewire.on('Objetivo borrado', function() {
        Swal.fire(
            'Objetivo borrado correctamente',
            'Se ha eliminado con exito',
            'success'
        )
    })
    Livewire.on('Objetivo editado', function() {
        Swal.fire(
            'Objetivo editado correctamente',
            'Se ha editado con exito',
            'success'
        )
        $('#editarObjetivo').modal('hide');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gladys\Documents\Proyecto\gice\resources\views/objetivo.blade.php ENDPATH**/ ?>
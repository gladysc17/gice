@extends('layouts.app')

@section('content')

<p> hola </p>

@endsection
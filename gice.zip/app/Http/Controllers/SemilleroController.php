<?php

namespace App\Http\Controllers;

use App\Models\Semillero;
use Illuminate\Http\Request;
use App\Models\Contacto;

class SemilleroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $semillero = Semillero::all();
        $contacto = Contacto::first();

        return view ('cliente.semillero', ['contacto' => $contacto, 'semillero'=> $semillero]);

        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Semillero  $semillero
     * @return \Illuminate\Http\Response
     */
    public function show(Semillero $semillero)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Semillero  $semillero
     * @return \Illuminate\Http\Response
     */
    public function edit(Semillero $semillero)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Semillero  $semillero
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Semillero $semillero)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Semillero  $semillero
     * @return \Illuminate\Http\Response
     */
    public function destroy(Semillero $semillero)
    {
        //
    }
}

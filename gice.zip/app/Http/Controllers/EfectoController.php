<?php

namespace App\Http\Controllers;

use App\Models\Efecto;
use Illuminate\Http\Request;

class EfectoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Efecto  $efecto
     * @return \Illuminate\Http\Response
     */
    public function show(Efecto $efecto)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Efecto  $efecto
     * @return \Illuminate\Http\Response
     */
    public function edit(Efecto $efecto)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Efecto  $efecto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Efecto $efecto)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Efecto  $efecto
     * @return \Illuminate\Http\Response
     */
    public function destroy(Efecto $efecto)
    {
        //
    }
}

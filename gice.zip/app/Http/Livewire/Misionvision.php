<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Misionvision extends Component
{
    public function render()
    {
        return view('livewire.misionvision');
    }
}
